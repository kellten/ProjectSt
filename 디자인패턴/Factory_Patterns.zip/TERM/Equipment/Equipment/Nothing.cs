using System;
using System.Collections.Generic;
using System.Text;

namespace Equipment
{
	public class Nothing : Equipment
	{
		public Nothing()
		{
			name = "ã�� �� ����";
		}
	}
}