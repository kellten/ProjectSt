using System;
using System.Collections.Generic;
using System.Text;

namespace Atmega
{
	public class Usart10 : EUsart
	{
		public Usart10() { }

		public string toString()
		{
			return "Usart       10 pin";
		}
	}
}
