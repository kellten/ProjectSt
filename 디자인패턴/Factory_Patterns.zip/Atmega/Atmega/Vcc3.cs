using System;
using System.Collections.Generic;
using System.Text;

namespace Atmega
{
	public class Vcc3 : EVcc
	{
		public Vcc3() { }

		public string toString()
		{
			return "Vcc       3volt";
		}
	}
}
