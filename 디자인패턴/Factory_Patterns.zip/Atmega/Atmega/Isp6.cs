using System;
using System.Collections.Generic;
using System.Text;

namespace Atmega
{
	public class Isp6 : EIsp
	{
		public Isp6() { }

		public string toString()
		{
			return "ISP         6 pin";
		}
	}
}
