using System;
using System.Collections.Generic;
using System.Text;

namespace Atmega
{
	public class SDCardY : ESDCard
	{
		public SDCardY() { }

		public string toString()
		{
			return "SDCard   ��� ����";
		}
	}
}
