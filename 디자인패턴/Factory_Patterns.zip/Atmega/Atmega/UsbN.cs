using System;
using System.Collections.Generic;
using System.Text;

namespace Atmega
{
	public class UsbN : EUsb
	{
		public UsbN() { }

		public string toString()
		{
			return "USB       ��� �Ұ�";
		}
	}
}
