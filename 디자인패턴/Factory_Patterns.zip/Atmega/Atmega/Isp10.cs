using System;
using System.Collections.Generic;
using System.Text;

namespace Atmega
{
	public class Isp10 : EIsp
	{
		public Isp10() { }

		public string toString()
		{
			return "ISP         10 pin";
		}
	}
}
