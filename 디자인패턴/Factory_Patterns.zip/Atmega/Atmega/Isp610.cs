using System;
using System.Collections.Generic;
using System.Text;

namespace Atmega
{
	public class Isp610 : EIsp
	{
		public Isp610() { }

		public string toString()
		{
			return "ISP         6, 10 pin";
		}
	}
}
