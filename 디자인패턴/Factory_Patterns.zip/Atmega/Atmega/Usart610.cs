using System;
using System.Collections.Generic;
using System.Text;

namespace Atmega
{
	public class Usart610 : EUsart
	{
		public Usart610() { }

		public string toString()
		{
			return "Usart       6, 10 pin";
		}
	}
}
