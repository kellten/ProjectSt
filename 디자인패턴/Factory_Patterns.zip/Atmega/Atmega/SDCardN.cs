using System;
using System.Collections.Generic;
using System.Text;

namespace Atmega
{
	public class SDCardN : ESDCard
	{
		public SDCardN() { }

		public string toString()
		{
			return "SDCard   ��� �Ұ�";
		}
	}
}
