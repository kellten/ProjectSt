using System;
using System.Collections.Generic;
using System.Text;

namespace Atmega
{
	public class Usart6 : EUsart
	{
		public Usart6() { }

		public string toString()
		{
			return "Usart       6 pin";
		}
	}
}
