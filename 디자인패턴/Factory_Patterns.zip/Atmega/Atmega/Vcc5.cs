using System;
using System.Collections.Generic;
using System.Text;

namespace Atmega
{
	public class Vcc5 : EVcc
	{
		public Vcc5() { }

		public string toString()
		{
			return "Vcc       5volt";
		}
	}
}
