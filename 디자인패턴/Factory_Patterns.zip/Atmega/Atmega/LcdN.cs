using System;
using System.Collections.Generic;
using System.Text;

namespace Atmega
{
	public class LcdN : ELcd
	{
		public LcdN() { }

		public string toString()
		{
			return "LCD        ��� �Ұ�";
		}
	}
}
