using System;
using System.Collections.Generic;
using System.Text;

namespace Atmega
{
	public class Lcd8 : ELcd
	{
		public Lcd8() { }

		public string toString()
		{
			return "LCD        8��Ʈ ��� ����";
		}
	}
}
