using System;
using System.Collections.Generic;
using System.Text;

namespace Atmega
{
	public class Lcd18 : ELcd
	{
		public Lcd18() { }

		public string toString()
		{
			return "LCD        18��Ʈ ��� ����";
		}
	}
}
