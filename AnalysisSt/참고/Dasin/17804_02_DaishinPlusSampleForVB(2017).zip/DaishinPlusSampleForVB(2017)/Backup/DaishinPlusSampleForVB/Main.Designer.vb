﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class Main
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Dim resources As System.ComponentModel.ComponentResourceManager = New System.ComponentModel.ComponentResourceManager(GetType(Main))
        Me.MenuStrip1 = New System.Windows.Forms.MenuStrip
        Me.ToolStripMenuItem1 = New System.Windows.Forms.ToolStripMenuItem
        Me.시세ToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem
        Me.주식현재가_단일종목_ToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem
        Me.주식현재가복수종목ToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem
        Me.투자주체별매매현황ToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem
        Me.주식시간대별체결ToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem
        Me.주식일자별ToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem
        Me.주식호가ToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem
        Me.주문ToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem
        Me.주식현금주문ToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem
        Me.주식매수가능금액수량ToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem
        Me.주식계좌별매도가능수량ToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem
        Me.주식예약주문ToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem
        Me.주식예약주문현황ToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem
        Me.체결ToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem
        Me.금일계좌별주문체결ToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem
        Me.금일전일체결기준내역ToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem
        Me.계좌별미체결잔량ToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem
        Me.주식체결실시간ToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem
        Me.잔고ToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem
        Me.계좌별잔고현황ToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem
        Me.주식결제예정예수금가계산ToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem
        Me.ToolStripMenuItem3 = New System.Windows.Forms.ToolStripMenuItem
        Me.주식시세종합화면ToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem
        Me.주식주문종합화면ToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem
        Me.설정ToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem
        Me.플러스접속ToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem
        Me.ToolStripSeparator1 = New System.Windows.Forms.ToolStripSeparator
        Me.화면모두닫기ToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem
        Me.MenuStrip1.SuspendLayout()
        Me.SuspendLayout()
        '
        'MenuStrip1
        '
        Me.MenuStrip1.BackColor = System.Drawing.Color.FromArgb(CType(CType(255, Byte), Integer), CType(CType(230, Byte), Integer), CType(CType(230, Byte), Integer))
        Me.MenuStrip1.Items.AddRange(New System.Windows.Forms.ToolStripItem() {Me.ToolStripMenuItem1, Me.ToolStripMenuItem3, Me.설정ToolStripMenuItem})
        Me.MenuStrip1.Location = New System.Drawing.Point(0, 0)
        Me.MenuStrip1.Name = "MenuStrip1"
        Me.MenuStrip1.Size = New System.Drawing.Size(1184, 24)
        Me.MenuStrip1.TabIndex = 3
        Me.MenuStrip1.Text = "MenuStrip1"
        '
        'ToolStripMenuItem1
        '
        Me.ToolStripMenuItem1.DropDownItems.AddRange(New System.Windows.Forms.ToolStripItem() {Me.시세ToolStripMenuItem, Me.주문ToolStripMenuItem, Me.체결ToolStripMenuItem, Me.잔고ToolStripMenuItem})
        Me.ToolStripMenuItem1.Name = "ToolStripMenuItem1"
        Me.ToolStripMenuItem1.Size = New System.Drawing.Size(83, 20)
        Me.ToolStripMenuItem1.Text = "[1000] 주식"
        '
        '시세ToolStripMenuItem
        '
        Me.시세ToolStripMenuItem.DropDownItems.AddRange(New System.Windows.Forms.ToolStripItem() {Me.주식현재가_단일종목_ToolStripMenuItem, Me.주식현재가복수종목ToolStripMenuItem, Me.투자주체별매매현황ToolStripMenuItem, Me.주식시간대별체결ToolStripMenuItem, Me.주식일자별ToolStripMenuItem, Me.주식호가ToolStripMenuItem})
        Me.시세ToolStripMenuItem.Name = "시세ToolStripMenuItem"
        Me.시세ToolStripMenuItem.Size = New System.Drawing.Size(152, 22)
        Me.시세ToolStripMenuItem.Text = "[1100] 시세"
        '
        '주식현재가_단일종목_ToolStripMenuItem
        '
        Me.주식현재가_단일종목_ToolStripMenuItem.Name = "주식현재가_단일종목_ToolStripMenuItem"
        Me.주식현재가_단일종목_ToolStripMenuItem.Size = New System.Drawing.Size(234, 22)
        Me.주식현재가_단일종목_ToolStripMenuItem.Text = "[1101] 주식현재가 (단일종목)"
        '
        '주식현재가복수종목ToolStripMenuItem
        '
        Me.주식현재가복수종목ToolStripMenuItem.Name = "주식현재가복수종목ToolStripMenuItem"
        Me.주식현재가복수종목ToolStripMenuItem.Size = New System.Drawing.Size(234, 22)
        Me.주식현재가복수종목ToolStripMenuItem.Text = "[1102] 관심종목"
        '
        '투자주체별매매현황ToolStripMenuItem
        '
        Me.투자주체별매매현황ToolStripMenuItem.Name = "투자주체별매매현황ToolStripMenuItem"
        Me.투자주체별매매현황ToolStripMenuItem.Size = New System.Drawing.Size(234, 22)
        Me.투자주체별매매현황ToolStripMenuItem.Text = "[1103] 투자주체별 현황"
        '
        '주식시간대별체결ToolStripMenuItem
        '
        Me.주식시간대별체결ToolStripMenuItem.Name = "주식시간대별체결ToolStripMenuItem"
        Me.주식시간대별체결ToolStripMenuItem.Size = New System.Drawing.Size(234, 22)
        Me.주식시간대별체결ToolStripMenuItem.Text = "[1104] 주식 시간대별 체결"
        '
        '주식일자별ToolStripMenuItem
        '
        Me.주식일자별ToolStripMenuItem.Name = "주식일자별ToolStripMenuItem"
        Me.주식일자별ToolStripMenuItem.Size = New System.Drawing.Size(234, 22)
        Me.주식일자별ToolStripMenuItem.Text = "[1105] 주식 일자별 주가"
        '
        '주식호가ToolStripMenuItem
        '
        Me.주식호가ToolStripMenuItem.Name = "주식호가ToolStripMenuItem"
        Me.주식호가ToolStripMenuItem.Size = New System.Drawing.Size(234, 22)
        Me.주식호가ToolStripMenuItem.Text = "[1106] 주식 호가"
        '
        '주문ToolStripMenuItem
        '
        Me.주문ToolStripMenuItem.DropDownItems.AddRange(New System.Windows.Forms.ToolStripItem() {Me.주식현금주문ToolStripMenuItem, Me.주식매수가능금액수량ToolStripMenuItem, Me.주식계좌별매도가능수량ToolStripMenuItem, Me.주식예약주문ToolStripMenuItem, Me.주식예약주문현황ToolStripMenuItem})
        Me.주문ToolStripMenuItem.Name = "주문ToolStripMenuItem"
        Me.주문ToolStripMenuItem.Size = New System.Drawing.Size(152, 22)
        Me.주문ToolStripMenuItem.Text = "[1200] 주문"
        '
        '주식현금주문ToolStripMenuItem
        '
        Me.주식현금주문ToolStripMenuItem.Name = "주식현금주문ToolStripMenuItem"
        Me.주식현금주문ToolStripMenuItem.Size = New System.Drawing.Size(287, 22)
        Me.주식현금주문ToolStripMenuItem.Text = "[1201] 주식 현금주문"
        '
        '주식매수가능금액수량ToolStripMenuItem
        '
        Me.주식매수가능금액수량ToolStripMenuItem.Name = "주식매수가능금액수량ToolStripMenuItem"
        Me.주식매수가능금액수량ToolStripMenuItem.Size = New System.Drawing.Size(287, 22)
        Me.주식매수가능금액수량ToolStripMenuItem.Text = "[1202] 주식 계좌별 매수 가능금액/수량"
        '
        '주식계좌별매도가능수량ToolStripMenuItem
        '
        Me.주식계좌별매도가능수량ToolStripMenuItem.Name = "주식계좌별매도가능수량ToolStripMenuItem"
        Me.주식계좌별매도가능수량ToolStripMenuItem.Size = New System.Drawing.Size(287, 22)
        Me.주식계좌별매도가능수량ToolStripMenuItem.Text = "[1203] 주식 계좌별 매도 가능수량"
        '
        '주식예약주문ToolStripMenuItem
        '
        Me.주식예약주문ToolStripMenuItem.Name = "주식예약주문ToolStripMenuItem"
        Me.주식예약주문ToolStripMenuItem.Size = New System.Drawing.Size(287, 22)
        Me.주식예약주문ToolStripMenuItem.Text = "[1204] 주식 예약주문"
        '
        '주식예약주문현황ToolStripMenuItem
        '
        Me.주식예약주문현황ToolStripMenuItem.Name = "주식예약주문현황ToolStripMenuItem"
        Me.주식예약주문현황ToolStripMenuItem.Size = New System.Drawing.Size(287, 22)
        Me.주식예약주문현황ToolStripMenuItem.Text = "[1205] 주식 예약주문 현황"
        '
        '체결ToolStripMenuItem
        '
        Me.체결ToolStripMenuItem.DropDownItems.AddRange(New System.Windows.Forms.ToolStripItem() {Me.금일계좌별주문체결ToolStripMenuItem, Me.금일전일체결기준내역ToolStripMenuItem, Me.계좌별미체결잔량ToolStripMenuItem, Me.주식체결실시간ToolStripMenuItem})
        Me.체결ToolStripMenuItem.Name = "체결ToolStripMenuItem"
        Me.체결ToolStripMenuItem.Size = New System.Drawing.Size(152, 22)
        Me.체결ToolStripMenuItem.Text = "[1300] 체결"
        '
        '금일계좌별주문체결ToolStripMenuItem
        '
        Me.금일계좌별주문체결ToolStripMenuItem.Name = "금일계좌별주문체결ToolStripMenuItem"
        Me.금일계좌별주문체결ToolStripMenuItem.Size = New System.Drawing.Size(258, 22)
        Me.금일계좌별주문체결ToolStripMenuItem.Text = "[1301] 금일 계좌별 주문체결 내역"
        '
        '금일전일체결기준내역ToolStripMenuItem
        '
        Me.금일전일체결기준내역ToolStripMenuItem.Name = "금일전일체결기준내역ToolStripMenuItem"
        Me.금일전일체결기준내역ToolStripMenuItem.Size = New System.Drawing.Size(258, 22)
        Me.금일전일체결기준내역ToolStripMenuItem.Text = "[1302] 금일/전일 체결기준 내역"
        '
        '계좌별미체결잔량ToolStripMenuItem
        '
        Me.계좌별미체결잔량ToolStripMenuItem.Name = "계좌별미체결잔량ToolStripMenuItem"
        Me.계좌별미체결잔량ToolStripMenuItem.Size = New System.Drawing.Size(258, 22)
        Me.계좌별미체결잔량ToolStripMenuItem.Text = "[1303] 계좌별 미체결잔량"
        '
        '주식체결실시간ToolStripMenuItem
        '
        Me.주식체결실시간ToolStripMenuItem.Name = "주식체결실시간ToolStripMenuItem"
        Me.주식체결실시간ToolStripMenuItem.Size = New System.Drawing.Size(258, 22)
        Me.주식체결실시간ToolStripMenuItem.Text = "[1304] 주식 체결 실시간"
        '
        '잔고ToolStripMenuItem
        '
        Me.잔고ToolStripMenuItem.DropDownItems.AddRange(New System.Windows.Forms.ToolStripItem() {Me.계좌별잔고현황ToolStripMenuItem, Me.주식결제예정예수금가계산ToolStripMenuItem})
        Me.잔고ToolStripMenuItem.Name = "잔고ToolStripMenuItem"
        Me.잔고ToolStripMenuItem.Size = New System.Drawing.Size(152, 22)
        Me.잔고ToolStripMenuItem.Text = "[1400] 잔고"
        '
        '계좌별잔고현황ToolStripMenuItem
        '
        Me.계좌별잔고현황ToolStripMenuItem.Name = "계좌별잔고현황ToolStripMenuItem"
        Me.계좌별잔고현황ToolStripMenuItem.Size = New System.Drawing.Size(266, 22)
        Me.계좌별잔고현황ToolStripMenuItem.Text = "[1401] 계좌별 잔고 평가현황"
        '
        '주식결제예정예수금가계산ToolStripMenuItem
        '
        Me.주식결제예정예수금가계산ToolStripMenuItem.Name = "주식결제예정예수금가계산ToolStripMenuItem"
        Me.주식결제예정예수금가계산ToolStripMenuItem.Size = New System.Drawing.Size(266, 22)
        Me.주식결제예정예수금가계산ToolStripMenuItem.Text = "[1402] 주식 결제예정예수금 가계산"
        '
        'ToolStripMenuItem3
        '
        Me.ToolStripMenuItem3.DropDownItems.AddRange(New System.Windows.Forms.ToolStripItem() {Me.주식시세종합화면ToolStripMenuItem, Me.주식주문종합화면ToolStripMenuItem})
        Me.ToolStripMenuItem3.Name = "ToolStripMenuItem3"
        Me.ToolStripMenuItem3.Size = New System.Drawing.Size(71, 20)
        Me.ToolStripMenuItem3.Text = "종합 화면"
        '
        '주식시세종합화면ToolStripMenuItem
        '
        Me.주식시세종합화면ToolStripMenuItem.Name = "주식시세종합화면ToolStripMenuItem"
        Me.주식시세종합화면ToolStripMenuItem.Size = New System.Drawing.Size(174, 22)
        Me.주식시세종합화면ToolStripMenuItem.Text = "주식시세 종합화면"
        '
        '주식주문종합화면ToolStripMenuItem
        '
        Me.주식주문종합화면ToolStripMenuItem.Name = "주식주문종합화면ToolStripMenuItem"
        Me.주식주문종합화면ToolStripMenuItem.Size = New System.Drawing.Size(174, 22)
        Me.주식주문종합화면ToolStripMenuItem.Text = "주식주문 종합화면"
        '
        '설정ToolStripMenuItem
        '
        Me.설정ToolStripMenuItem.DropDownItems.AddRange(New System.Windows.Forms.ToolStripItem() {Me.플러스접속ToolStripMenuItem, Me.ToolStripSeparator1, Me.화면모두닫기ToolStripMenuItem})
        Me.설정ToolStripMenuItem.Name = "설정ToolStripMenuItem"
        Me.설정ToolStripMenuItem.Size = New System.Drawing.Size(43, 20)
        Me.설정ToolStripMenuItem.Text = "설정"
        '
        '플러스접속ToolStripMenuItem
        '
        Me.플러스접속ToolStripMenuItem.Name = "플러스접속ToolStripMenuItem"
        Me.플러스접속ToolStripMenuItem.Size = New System.Drawing.Size(150, 22)
        Me.플러스접속ToolStripMenuItem.Text = "플러스 접속"
        '
        'ToolStripSeparator1
        '
        Me.ToolStripSeparator1.Name = "ToolStripSeparator1"
        Me.ToolStripSeparator1.Size = New System.Drawing.Size(147, 6)
        '
        '화면모두닫기ToolStripMenuItem
        '
        Me.화면모두닫기ToolStripMenuItem.Name = "화면모두닫기ToolStripMenuItem"
        Me.화면모두닫기ToolStripMenuItem.Size = New System.Drawing.Size(150, 22)
        Me.화면모두닫기ToolStripMenuItem.Text = "화면 모두닫기"
        '
        'Main
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(7.0!, 12.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.ClientSize = New System.Drawing.Size(1184, 752)
        Me.Controls.Add(Me.MenuStrip1)
        Me.Icon = CType(resources.GetObject("$this.Icon"), System.Drawing.Icon)
        Me.IsMdiContainer = True
        Me.MainMenuStrip = Me.MenuStrip1
        Me.Name = "Main"
        Me.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen
        Me.Text = "Daishin Plus Sample for VB"
        Me.MenuStrip1.ResumeLayout(False)
        Me.MenuStrip1.PerformLayout()
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub
    Friend WithEvents MenuStrip1 As System.Windows.Forms.MenuStrip
    Friend WithEvents ToolStripMenuItem1 As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents 시세ToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents 주식현재가_단일종목_ToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents 주식현재가복수종목ToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents 투자주체별매매현황ToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents 주식시간대별체결ToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents 주식일자별ToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents 주식호가ToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents 주문ToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents 주식현금주문ToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents 주식예약주문ToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents 주식매수가능금액수량ToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents 주식계좌별매도가능수량ToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents 체결ToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents 금일계좌별주문체결ToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents 잔고ToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents 계좌별잔고현황ToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents ToolStripMenuItem3 As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents 주식시세종합화면ToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents 주식주문종합화면ToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents 설정ToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents 플러스접속ToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents ToolStripSeparator1 As System.Windows.Forms.ToolStripSeparator
    Friend WithEvents 화면모두닫기ToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents 금일전일체결기준내역ToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents 계좌별미체결잔량ToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents 주식체결실시간ToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents 주식결제예정예수금가계산ToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents 주식예약주문현황ToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem

End Class
