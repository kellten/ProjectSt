﻿Public Class ClsServerInfo
    'Public Shared VADISSEVER As String = "EDPB2F011\VADIS"
    Public Shared VADISSEVER As String = "211.210.61.123, 8081"
    Public Shared RICHDB As String = "RICHDB"
    Public Shared KIWOOMDB As String = "KIWOOMDB"

    Sub New()
        'VADISSEVER = "EDPB2F011\VADIS"
        VADISSEVER = "211.210.61.123, 8081"
        RICHDB = "RICHDB"
        KIWOOMDB = "KIWOOMDB"
    End Sub

End Class

