﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Woom.DataDefine;

namespace Woom.DataAccess.ScreenNo.Interface
{
    internal interface IScreenNo
    {
        string BasicGetScreenNo(string formId, string ScreenNoFooter);
        string RealGetScreenNo(string formId, string ScreenNoFooter);
        
    }
}
