﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Woom.DataAccess.Interface;
using Woom.DataAccess.ScreenNo.Interface;

namespace Woom.DataAccess.ScreenNo.Class
{
    public class ClsScreenNoManage : IScreenNo
    {
        private static ClsScreenNoManage _instance = null;

        public static ClsScreenNoManage Instance()
        {
            //다중 쓰레드 환경일 경우 Lock 필요

            if (_instance == null)
            {
                lock (_instance)
                {
                    _instance = new ClsScreenNoManage();
                    _instance.MakeRealScreenNo();
                    _instance.MakeBaseScreenNo();
                }
            }

            return _instance;

        }

        private void MakeRealScreenNo()
        {

        }
        private void MakeBaseScreenNo()
        {

        }
        public string BasicGetScreenNo(string formId, string ScreenNoFooter)
        {

            return "";
        }
        public string RealGetScreenNo(string formId, string ScreenNoFooter)
        {
            return "";
        }
    }

    class ClsBaseScreenNoDataType
    {
        public string FormId;
    }
    class ClsRealScreenNoDataType
    {
        public string ScreenNo;
        public string StockCodes;
        public string FormId;
    }
}
