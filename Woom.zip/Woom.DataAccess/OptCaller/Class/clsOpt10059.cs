﻿using System;
using System.Data;
using System.Threading.Tasks;
using Woom.DataAccess.OptCaller.InterFace;
using Woom.DataDefine.OptData;
using static Woom.DataAccess.PlugIn.ClsAxKH;

namespace Woom.DataAccess.OptCaller.Class
{
    public class clsOpt10059 : IDisposable, IOptCaller
    {
        private const string ConScreenNoFooter = "59";
        public string ScreenNoFooter { get { return ConScreenNoFooter; } }
        private string _screenNo = "";
        
        private DataTable _dt = new DataTable();

        public delegate void OnReceivedEventHandler(string stockCode, DataTable dt, int sPreNext);
        public event OnReceivedEventHandler Opt10059_OnReceived;

        private enum Column10059Index
        {
            일자, 현재가, 대비기호, 전일대비, 등락율, 누적거래대금, 개인투자자, 
            외국인투자자, 기관계, 금융투자, 보험, 투신, 기타금융, 은행, 
            연기금등, 사모펀드, 국가, 기타법인, 내외국인
        }

        private string _startDate = "";
        private string _stockCode = "";
        private string _stockName = "";
        private string _amountQtyGb = "";
        private string _maeMaeGb = "";
        private string _unitGb = "";

        /// <summary>
        /// SetValue
        /// </summary>
        /// <param name="StartDate">일자</param>
        /// <param name="StockCode">종목코드</param>
        /// <param name="StockName">종목명</param>
        /// <param name="AmountQtyGb">금액수량구분 = 1:금액, 2:수량</param>
        /// <param name="MaeMaeGb">매매구분 = 0:순매수, 1:매수, 2:매도</param>
        /// <param name="UnitGb">단위구분 = 1000:천주, 1:단주</param>
        public void SetValue(string StartDate, string StockCode, string StockName, string AmountQtyGb, string MaeMaeGb, string UnitGb)
        {
            _startDate = StartDate;
            _stockCode = StockCode;
            _stockName = StockName;
            _amountQtyGb = AmountQtyGb;
            _maeMaeGb = MaeMaeGb;
            _unitGb = UnitGb;
        }

        private object lockObject = new object();
        public void SetInit(string FormId)
        {
            _screenNo = FormId + ConScreenNoFooter;
        }
        public void MakeDataTable()
        {
            if (_dt != null)
            {
                _dt = null;
                _dt = new DataTable();
            }

            using (ClsColumnSets oBasicDataType = new ClsColumnSets())
            {
                foreach (int i in Enum.GetValues(typeof(Column10059Index)))
                {
                    _dt.Columns.Add(oBasicDataType.GetDataColumn((ClsColumnSets.ColumnNameIndex)i));
                }
            };
        }


        public async void Opt10059(bool nextCall = false)
        {
            lock (lockObject)
            {
                AxKH.SetInputValue("일자", _startDate);
                AxKH.SetInputValue("종목코드", _stockCode);
                AxKH.SetInputValue("금액수량구분", _amountQtyGb);
                AxKH.SetInputValue("매매구분", _maeMaeGb);
                AxKH.SetInputValue("단위구분", _unitGb);
            }

            if (nextCall == false)
            {              
                await JustRequest();
            }
            else
            {
                await ReJustRequest();
            }

        }

        private async Task JustRequest()
        {
            TaskCompletionSource<bool> tcs = null;
            tcs = new TaskCompletionSource<bool>();
         
            AxKH.OnReceiveTrData += (object sender, AxKHOpenAPILib._DKHOpenAPIEvents_OnReceiveTrDataEvent e) =>
            {
                if (tcs == null || tcs.Task.IsCompleted)
                { return; }
                AxKH_OnReceiveTrData(sender, e);
                tcs.SetResult(true);
            };

            AxKH.CommRqData("종목별투자자기관별요청", "Opt10059", 0, _screenNo);
            await tcs.Task;

        }

        private async Task ReJustRequest()
        {
            await Task.Delay(TimeSpan.FromSeconds(2));
            TaskCompletionSource<bool> tcs = null;
            tcs = new TaskCompletionSource<bool>();

            AxKH.OnReceiveTrData += (object sender, AxKHOpenAPILib._DKHOpenAPIEvents_OnReceiveTrDataEvent e) =>
            {
                if (tcs == null || tcs.Task.IsCompleted)
                { return; }
                AxKH_OnReceiveTrData(sender, e);
                tcs.SetResult(true);
            };

            AxKH.CommRqData("종목별투자자기관별요청", "Opt10059", 2, _screenNo);
            await tcs.Task;

        }

        private void AxKH_OnReceiveTrData(object sender, AxKHOpenAPILib._DKHOpenAPIEvents_OnReceiveTrDataEvent e)
        {
            if (e.sScrNo != _screenNo || e.sRQName != "종목별투자자기관별요청")
            {
                return;
            }

            MakeDataTable();

            int nCnt = AxKH.GetRepeatCnt(e.sTrCode, e.sRQName);

            for (int i = 0; i < nCnt; i++)
            {
                DataRow dr = _dt.NewRow();
                for (int intColumName = 0; intColumName < _dt.Columns.Count; intColumName++)
                {
                    var type = _dt.Columns[intColumName].DataType;
                    dr[_dt.Columns[intColumName].ColumnName.ToString()] = Convert.ChangeType(AxKH.GetCommData(e.sTrCode, e.sRQName, i, _dt.Columns[intColumName].ColumnName.ToString()).ToString().Trim(), type);
                }

                _dt.Rows.Add(dr);
            }

            var handler = Opt10059_OnReceived;
            if (handler != null)
            { Opt10059_OnReceived(_stockCode, _dt, Convert.ToInt32(e.sPrevNext)); }
        }
                
        private void Dispose(bool disposing)
        {
            
        }
        public void Dispose()
        {
            this.Dispose(true);
            GC.SuppressFinalize(this);
        }

    }
}
