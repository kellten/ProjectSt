﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using Woom.DataAccess.OptCaller.Class;

namespace Woom.Tester.Forms
{
    public partial class FrmOptCallerTest : Form
    {
        public FrmOptCallerTest()
        {
            InitializeComponent();
            _opt10059.Opt10059_OnReceived += Opt10059_OnReceived;
        }
        private clsOpt10059 _opt10059 = new clsOpt10059();
        private void button1_Click(object sender, EventArgs e)
        {
            _opt10059.SetInit("01");
            _opt10059.SetValue("20170101", "088910", "동우팜투테이블", "1", "0", "1");
            _opt10059.Opt10059();
        }

        private void Opt10059_OnReceived(string stockCode, DataTable dt, int sPreNext)
        {
            richTextBox1.Text = richTextBox1.Text + dt.Rows[0]["일자"].ToString() +
                                           " - " + dt.Rows[dt.Rows.Count - 1]["일자"].ToString() + "\r\n";
            richTextBox1.SelectionStart = richTextBox1.Text.LastIndexOfAny(Environment.NewLine.ToCharArray()) + 1;

            richTextBox1.ScrollToCaret();

            if (sPreNext == 2)
            {
                _opt10059.Opt10059(true);
            }
        }
    }
}
